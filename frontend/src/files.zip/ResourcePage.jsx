import { api } from './api'
import { EntityForm, PageHeader, Panel, Notice, useList, pick } from './ui'

/** One list table + one add form. Used for cities, employers and candidates. */
export default function ResourcePage({ title, intro, listPath, addPath, fields, columns, addTitle, submitLabel, emptyText }) {
  const { items, loading, error, reload } = useList(listPath)

  return (
    <>
      <PageHeader title={title} intro={intro} />
      <div className="grid gap-6 xl:grid-cols-[1fr_380px]">
        <Panel title={`${title} (${items.length})`}>
          {error && <Notice ok={false}>{error}</Notice>}
          {loading ? (
            <p className="text-sm text-[#5B6B73]">Loading…</p>
          ) : items.length === 0 && !error ? (
            <p className="text-sm text-[#5B6B73]">{emptyText}</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-[#D9DFDC] text-[#5B6B73]">
                    {columns.map((c) => <th key={c.label} className="py-2 pr-4 font-medium">{c.label}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {items.map((row, i) => (
                    <tr key={row.id ?? i} className="border-b border-[#EDF0EE] last:border-0">
                      {columns.map((c) => (
                        <td key={c.label} className="py-2.5 pr-4 text-[#12303F]">
                          {c.render ? c.render(row) : pick(row, ...c.keys) ?? '—'}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
        <Panel title={addTitle}>
          <EntityForm
            fields={fields}
            submitLabel={submitLabel}
            onSubmit={async (payload) => {
              const r = await api.post(addPath, payload)
              reload()
              return r
            }}
          />
        </Panel>
      </div>
    </>
  )
}
