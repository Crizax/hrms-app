import { useState } from 'react'
import { api } from './api'
import { Button, EntityForm, Notice, PageHeader, Panel, pick, useList } from './ui'

const money = (n) => (n == null ? '—' : Number(n).toLocaleString())

function ApplyBox({ adId, candidates }) {
  const [candidateId, setCandidateId] = useState('')
  const [status, setStatus] = useState(null)
  const [busy, setBusy] = useState(false)

  const apply = async () => {
    setBusy(true); setStatus(null)
    try {
      const r = await api.post('/api/jobApplications/apply', {
        candidateId: Number(candidateId),
        jobAdvertisementId: adId,
      })
      setStatus({ ok: true, text: r.message || 'Application sent.' })
    } catch (e) {
      setStatus({ ok: false, text: e.message })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="mt-4 border-t border-[#EDF0EE] pt-4">
      <div className="flex flex-wrap gap-2">
        <select aria-label="Candidate" value={candidateId} onChange={(e) => setCandidateId(e.target.value)}
          className="min-w-0 flex-1 rounded-md border border-[#C9D2CE] bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E0A030]/60">
          <option value="">Apply as…</option>
          {candidates.map((c) => <option key={c.id} value={c.id}>{c.name} {c.lastName}</option>)}
        </select>
        <Button onClick={apply} disabled={!candidateId || busy}>{busy ? 'Applying…' : 'Apply'}</Button>
      </div>
      {status && <div className="mt-2"><Notice ok={status.ok}>{status.text}</Notice></div>}
    </div>
  )
}

export default function JobAds() {
  const ads = useList('/api/jobAdvertisements/getAll')
  const cities = useList('/api/cities/getAll')
  const employers = useList('/api/employers/getAll')
  const candidates = useList('/api/candidateController/getAll')
  const [cityFilter, setCityFilter] = useState('')

  const shown = ads.items.filter((a) => !cityFilter || String(pick(a, 'cityName', 'city.name', 'cityId', 'city.id')) === cityFilter)

  const fields = [
    { name: 'description', label: 'Description' },
    { name: 'openPositionCount', label: 'Open positions', type: 'number' },
    { name: 'minSalary', label: 'Minimum salary', type: 'number' },
    { name: 'maxSalary', label: 'Maximum salary', type: 'number' },
    { name: 'applicationDeadline', label: 'Application deadline', type: 'date' },
    { name: 'jobPositionId', label: 'Job position ID', type: 'number', placeholder: '1' },
    { name: 'cityId', label: 'City', numeric: true, options: cities.items.map((c) => ({ value: c.id, label: c.name })) },
    { name: 'employerId', label: 'Employer', numeric: true, options: employers.items.map((e) => ({ value: e.id, label: e.companyName })) },
  ]

  return (
    <>
      <PageHeader title="Job advertisements" intro="Browse open roles, apply as a candidate, or post a new advertisement." />
      <div className="grid gap-6 xl:grid-cols-[1fr_380px]">
        <div>
          <div className="mb-4 flex items-center gap-3">
            <label htmlFor="cityFilter" className="text-sm text-[#5B6B73]">City</label>
            <select id="cityFilter" value={cityFilter} onChange={(e) => setCityFilter(e.target.value)}
              className="rounded-md border border-[#C9D2CE] bg-white px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E0A030]/60">
              <option value="">All cities</option>
              {cities.items.map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}
            </select>
          </div>
          {ads.error && <Notice ok={false}>{ads.error}</Notice>}
          {ads.loading ? <p className="text-sm text-[#5B6B73]">Loading…</p>
            : shown.length === 0 ? <p className="text-sm text-[#5B6B73]">No advertisements match. Post the first one using the form.</p>
            : (
              <ul className="space-y-4">
                {shown.map((ad, i) => (
                  <li key={ad.id ?? i} className="rounded-lg border border-[#D9DFDC] bg-white p-5">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <h3 className="text-lg font-semibold text-[#12303F]">
                        {pick(ad, 'jobPositionName', 'jobPosition.name', 'jobPosition.title') ?? 'Job advertisement'}
                      </h3>
                      <span className="rounded bg-[#FBEFD3] px-2 py-0.5 text-sm font-medium text-[#7A5612]">
                        {money(ad.minSalary)} – {money(ad.maxSalary)}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-[#5B6B73]">
                      {pick(ad, 'companyName', 'employer.companyName', 'employerName') ?? 'Employer'}
                      {pick(ad, 'cityName', 'city.name') && `, ${pick(ad, 'cityName', 'city.name')}`}
                    </p>
                    <p className="mt-3 text-sm text-[#12303F]">{ad.description}</p>
                    <dl className="mt-3 flex flex-wrap gap-x-6 gap-y-1 text-sm text-[#5B6B73]">
                      <div><dt className="inline">Open positions: </dt><dd className="inline text-[#12303F]">{ad.openPositionCount ?? '—'}</dd></div>
                      <div><dt className="inline">Apply by: </dt><dd className="inline text-[#12303F]">{ad.applicationDeadline ?? '—'}</dd></div>
                    </dl>
                    <ApplyBox adId={ad.id} candidates={candidates.items} />
                  </li>
                ))}
              </ul>
            )}
        </div>
        <Panel title="Post an advertisement">
          <EntityForm
            fields={fields}
            submitLabel="Publish advertisement"
            onSubmit={async (payload) => {
              const r = await api.post('/api/jobAdvertisements/add', payload)
              ads.reload()
              return r
            }}
          />
        </Panel>
      </div>
    </>
  )
}
