import { useCallback, useEffect, useState } from 'react'
import { api } from './api'

export const display = { fontFamily: "'Bricolage Grotesque', system-ui, sans-serif" }

export const pick = (obj, ...paths) => {
  for (const p of paths) {
    const v = p.split('.').reduce((a, k) => a?.[k], obj)
    if (v != null && v !== '') return v
  }
  return null
}

export function useList(path) {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const reload = useCallback(async () => {
    setLoading(true)
    try {
      const r = await api.get(path)
      setItems(Array.isArray(r.data) ? r.data : [])
      setError('')
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [path])
  useEffect(() => { reload() }, [reload])
  return { items, loading, error, reload }
}

const inputCls =
  'w-full rounded-md border border-[#C9D2CE] bg-white px-3 py-2 text-sm text-[#12303F] ' +
  'focus:border-[#E0A030] focus:outline-none focus:ring-2 focus:ring-[#E0A030]/60'

export function Notice({ ok, children }) {
  return (
    <p role="status" className={`rounded-md px-3 py-2 text-sm ${ok ? 'bg-[#DDEFE7] text-[#175C44]' : 'bg-[#F6DEDB] text-[#8C2820]'}`}>
      {children}
    </p>
  )
}

export function Button({ className = '', ...props }) {
  return (
    <button
      {...props}
      className={`rounded-md bg-[#12303F] px-4 py-2 text-sm font-medium text-white transition hover:bg-[#1B4458] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#E0A030] disabled:opacity-50 ${className}`}
    />
  )
}

/** Generic form. fields: [{ name, label, type?, numeric?, options?, placeholder? }] */
export function EntityForm({ fields, submitLabel, onSubmit }) {
  const empty = Object.fromEntries(fields.map((f) => [f.name, '']))
  const [values, setValues] = useState(empty)
  const [busy, setBusy] = useState(false)
  const [status, setStatus] = useState(null)
  const [fieldErrors, setFieldErrors] = useState({})

  const submit = async (e) => {
    e.preventDefault()
    setBusy(true); setStatus(null); setFieldErrors({})
    const payload = Object.fromEntries(
      fields.map((f) => {
        const v = values[f.name]
        return [f.name, f.numeric || f.type === 'number' ? (v === '' ? null : Number(v)) : v]
      })
    )
    try {
      const r = await onSubmit(payload)
      setStatus({ ok: true, text: r.message || 'Saved.' })
      setValues(empty)
    } catch (err) {
      setStatus({ ok: false, text: err.message })
      if (err.data && typeof err.data === 'object' && !Array.isArray(err.data)) setFieldErrors(err.data)
    } finally {
      setBusy(false)
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      {fields.map((f) => (
        <div key={f.name}>
          <label htmlFor={f.name} className="mb-1 block text-sm font-medium text-[#12303F]">{f.label}</label>
          {f.options ? (
            <select id={f.name} className={inputCls} value={values[f.name]}
              onChange={(e) => setValues({ ...values, [f.name]: e.target.value })}>
              <option value="">Select…</option>
              {f.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          ) : (
            <input id={f.name} className={inputCls} type={f.type || 'text'} placeholder={f.placeholder}
              value={values[f.name]} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })} />
          )}
          {fieldErrors[f.name] && <p className="mt-1 text-xs text-[#B3342B]">{String(fieldErrors[f.name])}</p>}
        </div>
      ))}
      {status && <Notice ok={status.ok}>{status.text}</Notice>}
      <Button type="submit" disabled={busy}>{busy ? 'Saving…' : submitLabel}</Button>
    </form>
  )
}

export function PageHeader({ title, intro }) {
  return (
    <header className="mb-8">
      <h1 style={display} className="text-3xl font-bold tracking-tight text-[#12303F]">{title}</h1>
      <p className="mt-1 max-w-prose text-[#5B6B73]">{intro}</p>
    </header>
  )
}

export function Panel({ title, children }) {
  return (
    <section className="rounded-lg border border-[#D9DFDC] bg-white p-5">
      <h2 style={display} className="mb-4 text-lg font-semibold text-[#12303F]">{title}</h2>
      {children}
    </section>
  )
}
