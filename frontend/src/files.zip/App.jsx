import { BrowserRouter, NavLink, Navigate, Route, Routes } from 'react-router-dom'
import JobAds from './JobAds'
import { Candidates, Cities, Employers } from './pages'
import { display } from './ui'

const nav = [
  { to: '/jobs', label: 'Job advertisements' },
  { to: '/candidates', label: 'Candidates' },
  { to: '/employers', label: 'Employers' },
  { to: '/cities', label: 'Cities' },
]

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-[#F2F4F3] text-[#12303F] md:flex" style={{ fontFamily: "'Figtree', system-ui, sans-serif" }}>
        <aside className="bg-[#12303F] px-4 py-4 md:sticky md:top-0 md:h-screen md:w-60 md:shrink-0 md:px-5 md:py-8">
          <div style={display} className="mb-4 text-2xl font-bold text-white md:mb-10">
            HRMS<span className="text-[#E0A030]">.</span>
          </div>
          <nav className="flex gap-1 overflow-x-auto md:flex-col">
            {nav.map((n) => (
              <NavLink key={n.to} to={n.to}
                className={({ isActive }) =>
                  `whitespace-nowrap rounded-md px-3 py-2 text-sm transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#E0A030] ${
                    isActive ? 'bg-[#E0A030] font-semibold text-[#12303F]' : 'text-[#C5D3DA] hover:bg-[#1B4458]'}`}>
                {n.label}
              </NavLink>
            ))}
          </nav>
        </aside>
        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 md:px-10 md:py-10">
          <Routes>
            <Route path="/" element={<Navigate to="/jobs" replace />} />
            <Route path="/jobs" element={<JobAds />} />
            <Route path="/candidates" element={<Candidates />} />
            <Route path="/employers" element={<Employers />} />
            <Route path="/cities" element={<Cities />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}
